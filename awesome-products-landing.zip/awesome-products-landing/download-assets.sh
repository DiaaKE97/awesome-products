#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Downloads the client-supplied logo, hero image and gallery photos into
# assets/images/, using the direct i.postimg.cc URLs already resolved from
# the Postimages preview pages. Run this once from the project root:
#
#   bash download-assets.sh
#
# Requires curl. If a URL ever changes on the Postimages side, open the
# preview page (postimg.cc/xxxxxxx) in a browser, right-click the image,
# choose "Copy image address", and paste the new i.postimg.cc URL below.
# ---------------------------------------------------------------------------
set -e
cd "$(dirname "$0")"
mkdir -p assets/images

get() { # get <output-path> <url>
  echo "→ $1"
  curl -sSL --fail -o "$1" "$2" || echo "  ✗ failed — check the URL or your connection"
}

get assets/images/logo.png         "https://i.postimg.cc/tgwS1SZd/awesome-products-logo.png"
get assets/images/hero-product.jpg "https://i.postimg.cc/prJMJbKp/IMG-20260917-WA0001.jpg"

get assets/images/gallery-01.png "https://i.postimg.cc/vHXd1yQT/Screenshot-20260906-171529-watsab-lla%CA%BFmal.png"
get assets/images/gallery-02.png "https://i.postimg.cc/CLJVZ0FD/Screenshot-20260906-171735-Alibaba-com.png"
get assets/images/gallery-03.png "https://i.postimg.cc/h4LnBxNR/Screenshot-20260906-171323-watsab-lla%CA%BFmal.png"
get assets/images/gallery-04.png "https://i.postimg.cc/NfbwytgH/Screenshot-20260906-180556-alm%CA%BFrd.png"
get assets/images/gallery-05.png "https://i.postimg.cc/yYnzJKV0/Screenshot-20260906-180541-alm%CA%BFrd.png"
get assets/images/gallery-06.png "https://i.postimg.cc/KcPb2LwJ/Screenshot-20260906-171401-watsab-lla%CA%BFmal.png"

cat <<'EOF'

Done. Two things to check by hand:

1. index.html currently expects gallery-01.jpg … gallery-06.jpg (a .jpg
   extension). The files just downloaded are .png. Either:
     a) rename them to .jpg (a PNG opens fine even with a .jpg name), or
     b) edit the six <img src="assets/images/gallery-0N.jpg" ...> lines in
        index.html to say .png instead.

2. The gallery images supplied are phone screenshots (WhatsApp Business /
   Alibaba), not clean product photos. Replace them with real, cropped
   photos of the necklaces before publishing — see README.md, "Gallery
   images" section.

The advertisement video is not hosted anywhere yet — copy your own file to
assets/video/advertisement.mp4 and a still frame to
assets/video/video-poster.jpg.
EOF
